#include <windows.h>
#include <nvml.h>

#include <algorithm>
#include <array>
#include <string>
#include <vector>

namespace {

constexpr wchar_t kWindowClass[] = L"NvidiaInfoGpuMonitorWindow";
constexpr int kTimerId = 1;
constexpr int kSampleIntervalMs = 2000;
constexpr int kHistoryCapacity = 31;
constexpr int kHeaderHeight = 100;
constexpr int kCardHeight = 190;
constexpr int kCardGap = 12;

const COLORREF kBackground = RGB(19, 23, 27);
const COLORREF kCardBackground = RGB(29, 35, 39);
const COLORREF kPlotBackground = RGB(22, 28, 31);
const COLORREF kGridColor = RGB(53, 63, 67);
const COLORREF kPrimaryText = RGB(234, 240, 239);
const COLORREF kMutedText = RGB(145, 160, 161);
const COLORREF kAccent = RGB(65, 212, 169);
const COLORREF kTemperature = RGB(255, 174, 96);
const COLORREF kWarning = RGB(255, 129, 111);

struct Sample {
    unsigned int load = 0;
    bool valid = false;
};

struct GpuInfo {
    nvmlDevice_t device = nullptr;
    std::wstring name;
    std::wstring driverMode;
    unsigned int load = 0;
    unsigned int temperature = 0;
    bool loadValid = false;
    bool temperatureValid = false;
    bool driverModeValid = false;
    std::array<Sample, kHistoryCapacity> history{};
    int historyNext = 0;
    int historyCount = 0;
};

struct Fonts {
    HFONT title = nullptr;
    HFONT heading = nullptr;
    HFONT body = nullptr;
    HFONT metric = nullptr;
};

struct AppState {
    std::vector<GpuInfo> gpus;
    std::wstring status;
    bool nvmlInitialized = false;
    int scrollPosition = 0;
    Fonts fonts;
};

std::wstring ToWide(const char* text) {
    if (text == nullptr || *text == '\0') {
        return {};
    }

    const int length = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);
    if (length <= 1) {
        return {};
    }

    std::wstring result(static_cast<size_t>(length), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text, -1, result.data(), length);
    result.resize(static_cast<size_t>(length - 1));
    return result;
}

std::wstring NvmlError(const char* operation, nvmlReturn_t result) {
    std::wstring message = ToWide(operation);
    message += L": ";
    message += ToWide(nvmlErrorString(result));
    return message;
}

std::wstring GetDriverMode(nvmlDevice_t device, bool& valid) {
    nvmlDriverModel_t current{};
    nvmlDriverModel_t pending{};
    valid = nvmlDeviceGetDriverModel(device, &current, &pending) == NVML_SUCCESS;
    if (!valid) {
        return L"MODE N/A";
    }

    switch (current) {
    case NVML_DRIVER_WDM: return L"TCC";
    case NVML_DRIVER_WDDM: return L"WDDM";
    case NVML_DRIVER_MCDM: return L"MCDM";
    default: return L"UNKNOWN";
    }
}

void AddSample(GpuInfo& gpu) {
    nvmlUtilization_t utilization{};
    gpu.loadValid = nvmlDeviceGetUtilizationRates(gpu.device, &utilization) == NVML_SUCCESS;
    if (gpu.loadValid) {
        gpu.load = utilization.gpu;
    }

    gpu.temperatureValid = nvmlDeviceGetTemperature(
        gpu.device, NVML_TEMPERATURE_GPU, &gpu.temperature) == NVML_SUCCESS;

    gpu.history[gpu.historyNext] = {gpu.load, gpu.loadValid};
    gpu.historyNext = (gpu.historyNext + 1) % kHistoryCapacity;
    gpu.historyCount = std::min(gpu.historyCount + 1, kHistoryCapacity);
}

void Refresh(AppState& state) {
    for (GpuInfo& gpu : state.gpus) {
        AddSample(gpu);
    }
}

void InitializeNvml(AppState& state) {
    nvmlReturn_t result = nvmlInit_v2();
    if (result != NVML_SUCCESS) {
        state.status = NvmlError("NVML initialization failed", result);
        return;
    }
    state.nvmlInitialized = true;

    unsigned int deviceCount = 0;
    result = nvmlDeviceGetCount_v2(&deviceCount);
    if (result != NVML_SUCCESS) {
        state.status = NvmlError("Could not enumerate GPUs", result);
        return;
    }

    for (unsigned int index = 0; index < deviceCount; ++index) {
        nvmlDevice_t device = nullptr;
        result = nvmlDeviceGetHandleByIndex_v2(index, &device);
        if (result != NVML_SUCCESS) {
            continue;
        }

        char deviceName[NVML_DEVICE_NAME_BUFFER_SIZE]{};
        if (nvmlDeviceGetName(device, deviceName, sizeof(deviceName)) != NVML_SUCCESS) {
            wsprintfA(deviceName, "GPU %u", index);
        }

        GpuInfo gpu;
        gpu.device = device;
        gpu.name = ToWide(deviceName);
        gpu.driverMode = GetDriverMode(device, gpu.driverModeValid);
        state.gpus.push_back(gpu);
    }

    if (state.gpus.empty()) {
        state.status = L"No NVIDIA GPUs found";
        return;
    }

    state.status = std::to_wstring(state.gpus.size()) + L" NVIDIA GPU";
    if (state.gpus.size() != 1) {
        state.status += L"s";
    }
    state.status += L"  |  Sampling every 2 seconds";
    Refresh(state);
}

void DrawText(HDC dc, const std::wstring& text, RECT bounds, HFONT font, COLORREF color,
    UINT format = DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS) {
    const HGDIOBJ previous = SelectObject(dc, font);
    SetTextColor(dc, color);
    SetBkMode(dc, TRANSPARENT);
    DrawTextW(dc, text.c_str(), static_cast<int>(text.size()), &bounds, format);
    SelectObject(dc, previous);
}

void FillRectColor(HDC dc, const RECT& bounds, COLORREF color) {
    HBRUSH brush = CreateSolidBrush(color);
    FillRect(dc, &bounds, brush);
    DeleteObject(brush);
}

void DrawGraph(HDC dc, const GpuInfo& gpu, RECT bounds, const Fonts& fonts) {
    FillRectColor(dc, bounds, kPlotBackground);

    const int left = bounds.left + 42;
    const int right = bounds.right - 12;
    const int top = bounds.top + 14;
    const int bottom = bounds.bottom - 20;
    if (right <= left || bottom <= top) {
        return;
    }

    HPEN gridPen = CreatePen(PS_SOLID, 1, kGridColor);
    HGDIOBJ previousPen = SelectObject(dc, gridPen);
    for (int division = 0; division <= 4; ++division) {
        const int y = top + (bottom - top) * division / 4;
        MoveToEx(dc, left, y, nullptr);
        LineTo(dc, right, y);
    }
    SelectObject(dc, previousPen);
    DeleteObject(gridPen);

    DrawText(dc, L"100", {bounds.left + 4, top - 8, bounds.left + 36, top + 8},
        fonts.body, kMutedText, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
    DrawText(dc, L"50", {bounds.left + 4, (top + bottom) / 2 - 8, bounds.left + 36,
        (top + bottom) / 2 + 8}, fonts.body, kMutedText,
        DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
    DrawText(dc, L"0", {bounds.left + 4, bottom - 8, bounds.left + 36, bottom + 8},
        fonts.body, kMutedText, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);

    const int plotWidth = right - left;
    const int plotHeight = bottom - top;
    const int firstHistoryIndex =
        (gpu.historyNext - gpu.historyCount + kHistoryCapacity) % kHistoryCapacity;
    std::array<POINT, kHistoryCapacity> points{};
    std::array<bool, kHistoryCapacity> valid{};

    for (int index = 0; index < gpu.historyCount; ++index) {
        const Sample& sample = gpu.history[(firstHistoryIndex + index) % kHistoryCapacity];
        const int timelineIndex = kHistoryCapacity - gpu.historyCount + index;
        points[index].x = left + plotWidth * timelineIndex / (kHistoryCapacity - 1);
        points[index].y = bottom - plotHeight * std::min(sample.load, 100U) / 100;
        valid[index] = sample.valid;
    }

    HPEN loadPen = CreatePen(PS_SOLID, 2, kAccent);
    previousPen = SelectObject(dc, loadPen);
    for (int index = 1; index < gpu.historyCount; ++index) {
        if (valid[index - 1] && valid[index]) {
            MoveToEx(dc, points[index - 1].x, points[index - 1].y, nullptr);
            LineTo(dc, points[index].x, points[index].y);
        }
    }
    if (gpu.historyCount == 1 && valid[0]) {
        Ellipse(dc, points[0].x - 3, points[0].y - 3, points[0].x + 4, points[0].y + 4);
    }
    SelectObject(dc, previousPen);
    DeleteObject(loadPen);

    DrawText(dc, L"60 seconds ago", {left, bounds.bottom - 19, left + 100, bounds.bottom},
        fonts.body, kMutedText);
    DrawText(dc, L"now", {right - 42, bounds.bottom - 19, right, bounds.bottom},
        fonts.body, kMutedText, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
}

void DrawGpuCard(HDC dc, const GpuInfo& gpu, RECT card, const Fonts& fonts) {
    FillRectColor(dc, card, kCardBackground);

    RECT nameBounds{card.left + 20, card.top + 12, card.right - 160, card.top + 40};
    DrawText(dc, gpu.name, nameBounds, fonts.heading, kPrimaryText);

    RECT modeBounds{card.right - 150, card.top + 12, card.right - 18, card.top + 40};
    const COLORREF modeColor = gpu.driverMode == L"TCC" ? kAccent
        : (gpu.driverModeValid ? kMutedText : kWarning);
    DrawText(dc, gpu.driverMode, modeBounds, fonts.body, modeColor, DT_RIGHT | DT_VCENTER
        | DT_SINGLELINE | DT_END_ELLIPSIS);

    RECT loadLabel{card.left + 20, card.top + 49, card.left + 166, card.top + 70};
    DrawText(dc, L"GPU LOAD", loadLabel, fonts.body, kMutedText);

    const std::wstring loadText = gpu.loadValid ? std::to_wstring(gpu.load) + L"%" : L"--";
    RECT loadValue{card.left + 18, card.top + 65, card.left + 188, card.top + 116};
    DrawText(dc, loadText, loadValue, fonts.metric, gpu.loadValid ? kAccent : kWarning);

    RECT temperatureLabel{card.left + 20, card.top + 119, card.left + 180, card.top + 140};
    DrawText(dc, L"TEMPERATURE", temperatureLabel, fonts.body, kMutedText);

    const std::wstring temperatureText = gpu.temperatureValid
        ? std::to_wstring(gpu.temperature) + L" C"
        : L"--";
    RECT temperatureValue{card.left + 20, card.top + 138, card.left + 180, card.top + 166};
    DrawText(dc, temperatureText, temperatureValue, fonts.heading,
        gpu.temperatureValid ? kTemperature : kWarning);

    RECT graphBounds{card.left + 198, card.top + 48, card.right - 16, card.bottom - 12};
    DrawGraph(dc, gpu, graphBounds, fonts);
}

int ContentHeight(const AppState& state) {
    if (state.gpus.empty()) {
        return kHeaderHeight + 100;
    }
    return kHeaderHeight + 16 + static_cast<int>(state.gpus.size()) * (kCardHeight + kCardGap);
}

void UpdateScrollBar(HWND window, AppState& state) {
    RECT client{};
    GetClientRect(window, &client);
    const int clientHeight = static_cast<int>(client.bottom - client.top);
    const int maxPosition = std::max(0, ContentHeight(state) - clientHeight);
    state.scrollPosition = std::clamp(state.scrollPosition, 0, maxPosition);

    SCROLLINFO info{};
    info.cbSize = sizeof(info);
    info.fMask = SIF_RANGE | SIF_PAGE | SIF_POS;
    info.nMin = 0;
    info.nMax = std::max(0, ContentHeight(state) - 1);
    info.nPage = static_cast<UINT>(client.bottom - client.top);
    info.nPos = state.scrollPosition;
    SetScrollInfo(window, SB_VERT, &info, TRUE);
}

void SetScrollPosition(HWND window, AppState& state, int position) {
    state.scrollPosition = position;
    UpdateScrollBar(window, state);
    InvalidateRect(window, nullptr, FALSE);
}

void PaintWindow(HWND window, AppState& state) {
    PAINTSTRUCT paint{};
    HDC dc = BeginPaint(window, &paint);

    RECT client{};
    GetClientRect(window, &client);
    FillRectColor(dc, client, kBackground);

    RECT titleBounds{24, 15, client.right - 24, 48};
    DrawText(dc, L"GPU MONITOR", titleBounds, state.fonts.title, kPrimaryText);

    RECT statusBounds{26, 51, client.right - 24, 76};
    const COLORREF statusColor = state.nvmlInitialized ? kMutedText : kWarning;
    DrawText(dc, state.status, statusBounds, state.fonts.body, statusColor);

    if (state.gpus.empty()) {
        RECT messageBounds{24, kHeaderHeight + 20, client.right - 24, kHeaderHeight + 70};
        DrawText(dc, state.status.empty() ? L"Waiting for NVML" : state.status,
            messageBounds, state.fonts.heading, kPrimaryText);
    } else {
        for (size_t index = 0; index < state.gpus.size(); ++index) {
            const int top = kHeaderHeight + 12 + static_cast<int>(index) * (kCardHeight + kCardGap)
                - state.scrollPosition;
            RECT card{18, top, client.right - 18, top + kCardHeight};
            DrawGpuCard(dc, state.gpus[index], card, state.fonts);
        }
    }

    EndPaint(window, &paint);
}

void DestroyFonts(Fonts& fonts) {
    if (fonts.title) DeleteObject(fonts.title);
    if (fonts.heading) DeleteObject(fonts.heading);
    if (fonts.body) DeleteObject(fonts.body);
    if (fonts.metric) DeleteObject(fonts.metric);
}

void CreateFonts(Fonts& fonts) {
    fonts.title = CreateFontW(24, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    fonts.heading = CreateFontW(17, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
        DEFAULT_PITCH, L"Segoe UI");
    fonts.body = CreateFontW(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Segoe UI");
    fonts.metric = CreateFontW(32, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
        DEFAULT_PITCH, L"Segoe UI");
}

LRESULT CALLBACK WindowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    AppState* state = reinterpret_cast<AppState*>(GetWindowLongPtrW(window, GWLP_USERDATA));

    switch (message) {
    case WM_NCCREATE: {
        const auto* create = reinterpret_cast<const CREATESTRUCTW*>(lParam);
        SetWindowLongPtrW(window, GWLP_USERDATA,
            reinterpret_cast<LONG_PTR>(create->lpCreateParams));
        return TRUE;
    }
    case WM_CREATE:
        state = reinterpret_cast<AppState*>(GetWindowLongPtrW(window, GWLP_USERDATA));
        CreateFonts(state->fonts);
        InitializeNvml(*state);
        SetTimer(window, kTimerId, kSampleIntervalMs, nullptr);
        UpdateScrollBar(window, *state);
        return 0;
    case WM_TIMER:
        if (state && wParam == kTimerId && state->nvmlInitialized) {
            Refresh(*state);
            InvalidateRect(window, nullptr, FALSE);
        }
        return 0;
    case WM_SIZE:
        if (state) UpdateScrollBar(window, *state);
        return 0;
    case WM_VSCROLL:
        if (state) {
            SCROLLINFO info{};
            info.cbSize = sizeof(info);
            info.fMask = SIF_ALL;
            GetScrollInfo(window, SB_VERT, &info);
            int position = state->scrollPosition;
            switch (LOWORD(wParam)) {
            case SB_LINEUP: position -= 48; break;
            case SB_LINEDOWN: position += 48; break;
            case SB_PAGEUP: position -= static_cast<int>(info.nPage); break;
            case SB_PAGEDOWN: position += static_cast<int>(info.nPage); break;
            case SB_THUMBTRACK: position = info.nTrackPos; break;
            case SB_THUMBPOSITION: position = info.nTrackPos; break;
            case SB_TOP: position = 0; break;
            case SB_BOTTOM: position = info.nMax; break;
            default: return 0;
            }
            SetScrollPosition(window, *state, position);
        }
        return 0;
    case WM_MOUSEWHEEL:
        if (state) {
            const int delta = GET_WHEEL_DELTA_WPARAM(wParam);
            SetScrollPosition(window, *state,
                state->scrollPosition - delta / WHEEL_DELTA * 48);
        }
        return 0;
    case WM_GETMINMAXINFO: {
        auto* limits = reinterpret_cast<MINMAXINFO*>(lParam);
        limits->ptMinTrackSize.x = 680;
        limits->ptMinTrackSize.y = 360;
        return 0;
    }
    case WM_PAINT:
        if (state) PaintWindow(window, *state);
        else return DefWindowProcW(window, message, wParam, lParam);
        return 0;
    case WM_DESTROY:
        if (state) {
            KillTimer(window, kTimerId);
            if (state->nvmlInitialized) nvmlShutdown();
            DestroyFonts(state->fonts);
        }
        PostQuitMessage(0);
        return 0;
    default:
        return DefWindowProcW(window, message, wParam, lParam);
    }
}

} // namespace

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int showCommand) {
    AppState state;
    WNDCLASSEXW windowClass{};
    windowClass.cbSize = sizeof(windowClass);
    windowClass.lpfnWndProc = WindowProc;
    windowClass.hInstance = instance;
    windowClass.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    windowClass.hbrBackground = nullptr;
    windowClass.lpszClassName = kWindowClass;

    if (!RegisterClassExW(&windowClass)) {
        return 1;
    }

    HWND window = CreateWindowExW(0, kWindowClass, L"NVIDIA GPU Monitor",
        WS_OVERLAPPEDWINDOW | WS_VSCROLL, CW_USEDEFAULT, CW_USEDEFAULT, 900, 620,
        nullptr, nullptr, instance, &state);
    if (!window) {
        return 1;
    }

    ShowWindow(window, showCommand);
    UpdateWindow(window);

    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    return static_cast<int>(message.wParam);
}
